from protorpc import message_types
from protorpc import remote
from google.appengine.ext import ndb
import models
import resources

@endpoints.api(name='meetings', version='v1')
class MeetingsApi(remote.Service):
    """
    The request object contains the email address and the corrosponding authentication token
    """
    @endpoints.method(message_types.VoidMessage,
        resources.MeetingCollection,
        path='meetings',
        http_method='GET',
        name='meetings.meetingssList')
    def meeting_list(self, request):
        items = []
        for meeting in models.Meeting.query(request.userName).fetch():
            checkl_items = []
            r = resources.MeetingRepr(key=meeting.key.urlsafe(), title=meeting.title, startTime=meeting.startTime)
            items.append(r)
        return resources.MeetingCollection(items=items)

    @endpoints.method(  resources.MeetingRepr,
                        resources.MeetingRepr,
                        path='meetings',
                        http_method='POST',
                        name='meetings.meetingsCreate')
    def meeting_create(self, new_resource):
        meeting = models.Meeting( localId = new_resource.localId, status = new_resource.status, title = new_resource.title, startTime = new_resource.startTime)
        meeting.put()
        new_resource.key = meeting.key.urlsafe()
        return new_resource


    @endpoints.method(resources.MeetingsCollection,
                        message_types.VoidMessage,
                        path='meetings',
                        http_method='PUT',
                        name='meetings.meetingsBatchUpdate')
    def meeting_batch_update(self, collection):
        for meeting_repr in collection.items:
            meeting = ndb.Key(urlsafe=meeting_repr.key).get()
            meeting.title = meeting_repr.title
            meeting.status = meeting_repr.status
            meeting.startTime = meeting_repr.startTime
            meeting.put()
        return message_types.VoidMessage()


    @endpoints.method(MeetingRequestContainer,
                        resources.MeetingRepr,
                        path='meetings/{key}',
                        http_method='GET',
                        name='meetings.meetingsDetail')
        def meeting_get(self, request):
        meeting = ndb.Key(urlsafe=request.key).get()
        return resources.meetingRepr(  key=request.key,
                                        title=meeting.title,
                                        status=meeting.status,
                                        startTime=meeting.startTime)

    # @endpoints.method(  MeetingsRequestContainer,
    #                     message_types.VoidMessage,
    #                     path='meetings/{key}',
    #                     http_method='POST',
    #                     name='meetings.meetingsDetailPost')
    #                     def meeting_get_post(self, request):

    @endpoints.method(  meetingRequestContainer,
                        resources.meetingRepr,
                        path='meetings/{key}',
                        http_method='PUT',
                        name='meetings.meetingsUpdate')
    def meeting_update(self, request):
        meeting = ndb.Key(urlsafe=request.key).get()
        meeting.title = request.title
        meeting.status = request.status
        meeting.startTime = request.startTime
        meeting.put()
        return resources.meetingRepr(   key=request.key,
                                        title=meeting.title,
                                        status=meeting.status,
                                        startTime=meeting.startTime)

    

app = endpoints.api_server([MeetingsApi])

#@endpoints.api(name='meetings', version='v1')
#class meetingsApi(remote.Service):
#    @endpoints.method(message_types.VoidMessage,
#        resources.meetingCollection,
#        path='meetings',
#        http_method='GET',
#        name='meetings.meetingsList')
#    def meeting_list(self, unused_request_msg):
#        items = []
#        for meeting in models.meeting.query().fetch():
#            checkl_items = []
#            for i in meeting.checklist_items:
#                checkl_items.append(resources.CheckListItemRepr(title=i.title, checked=i.checked))
#            files = [f.urlsafe() for f in meeting.files]
#            r = resources.meetingRepr(key=meeting.key.urlsafe(), title=meeting.title, content=meeting.content, date_created=meeting.date_created, checklist_items=checkl_items, files=files)
#            items.append(r)
#        return resources.meetingCollection(items=items)

#app = endpoints.api_server([meetingsApi])