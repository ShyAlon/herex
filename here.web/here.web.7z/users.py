

class users:
    @classmethod
    def authenticate(cls, email, token):
        return True
